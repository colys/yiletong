﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Cryptography;
using System.IO;

namespace Utility
{
    public class RSACryptionClass
    {

        #region 加密解密demo
        ////公开金钥加密
        //private void btnEncrypt_Click(object sender, EventArgs e)
        //{
        //    //txtPublicKeyPath.Text是公开金钥的档案路径
        //    X509Certificate2 pubcrt = new X509Certificate2(txtPublicKeyPath.Text.Trim());
        //    RSACryptoServiceProvider pubkey = (RSACryptoServiceProvider)pubcrt.PublicKey.Key;
        //    //txtBody.Text是要加密的内容
        //    byte[] orgData = Encoding.UTF8.GetBytes(txtBody.Text.Trim());
        //    //公开金钥加密
        //    byte[] encryptedData = RSAEncrypt(orgData, pubkey.ExportParameters(false), false);
        //    //将加密过的内容以Base64转成字符串
        //    txtEncryptBody.Text = Convert.ToBase64String(encryptedData);
        //}

        // //私密金钥解密
        //private void btnDecrypt_Click(object sender, EventArgs e)
        //{
        //    //txtPrivateKeyPath.Text是私密金钥解密的档案路径
        //    // txtPrivateKeyPass<a href="http://www.it165.net/edu/ebg/" target="_blank" class="keylink">word</a>.Text是私密金钥解密的密码
        //    X509Certificate2 prvcrt = new X509Certificate2(txtPrivateKeyPath.Text.Trim(), 
        //        txtPrivateKeyPass<a href="http://www.it165.net/edu/ebg/" target="_blank" class="keylink">word</a>.Text, X509KeyStorageFlags.Exportable);
        //    RSACryptoServiceProvider prvkey = (RSACryptoServiceProvider)prvcrt.PrivateKey;
        //    //将加密过的内容从Base64字符串转成Byte Array
        //    byte[] encryptedData = Convert.FromBase64String(txtEncryptBody.Text);
        //    System.Security.Cryptography.RSAParameters parms = prvkey.ExportParameters(true);
        //    //私密金钥解密
        //    byte[] decryptedData = RSADecrypt(encryptedData, parms, false);
        //    //将解密出来的内容转成字符串
        //    txtDecryptBody.Text = Encoding.UTF8.GetString(decryptedData);
        //}
        #endregion

        #region RSA证书加密解密(支持大数据量)
        //The key size to use maybe 1024/2048
        private const int _EncryptionKeySize = 1024;

        // The buffer size to decrypt per set
        private const int _DecryptionBufferSize = (_EncryptionKeySize / 8);

        //The buffer size to encrypt per set
        private const int _EncryptionBufferSize = _DecryptionBufferSize - 11;

        static public byte[] RSAEncrypt(byte[] DataToEncrypt, RSAParameters RSAKeyInfo, bool DoOAEPPadding)
        {
            try
            {
                //byte[] encryptedData;
                //Create a new instance of RSACryptoServiceProvider.
                using (RSACryptoServiceProvider RSA = new RSACryptoServiceProvider())
                {
                    //Import the RSA Key information. This only needs www.it165.net
                    //toinclude the public key information.
                    RSA.ImportParameters(RSAKeyInfo);

                    ////Encrypt the passed byte array and specify OAEP padding.  
                    ////OAEP padding is only available on Microsoft Windows XP or
                    ////later.  
                    //encryptedData = RSA.Encrypt(DataToEncrypt, DoOAEPPadding);
                    //2012/10/19 rm 改用block
                    using (MemoryStream ms = new MemoryStream())
                    {
                        byte[] buffer = new byte[_EncryptionBufferSize];
                        int pos = 0;
                        int copyLength = buffer.Length;
                        while (true)
                        {
                            //Check if the bytes left to read is smaller than the buffer size, 
                            //then limit the buffer size to the number of bytes left

                            if (pos + copyLength > DataToEncrypt.Length)

                                copyLength = DataToEncrypt.Length - pos;

                            //Create a new buffer that has the correct size

                            buffer = new byte[copyLength];

                            //Copy as many bytes as the algorithm can handle at a time, 
                            //iterate until the whole input array is encoded

                            Array.Copy(DataToEncrypt, pos, buffer, 0, copyLength);

                            //Start from here in next iteration

                            pos += copyLength;

                            //Encrypt the data using the public key and add it to the memory buffer

                            //_DecryptionBufferSize is the size of the encrypted data

                            ms.Write(RSA.Encrypt(buffer, false), 0, _DecryptionBufferSize);

                            //Clear the content of the buffer, 
                            //otherwise we could end up copying the same data during the last iteration

                            Array.Clear(buffer, 0, copyLength);

                            //Check if we have reached the end, then exit

                            if (pos >= DataToEncrypt.Length)

                                break;
                        }
                        return ms.ToArray();
                    }
                }
                //return encryptedData;
            }
            //Catch and display a CryptographicException  
            //to the console.
            catch (CryptographicException e)
            {
                Console.WriteLine(e.Message);

                return null;
            }

        }

        static public byte[] RSADecrypt(byte[] DataToDecrypt, RSAParameters RSAKeyInfo, bool DoOAEPPadding)
        {
            try
            {
                //byte[] decryptedData;
                //Create a new instance of RSACryptoServiceProvider.
                using (RSACryptoServiceProvider RSA = new RSACryptoServiceProvider())
                {
                    //Import the RSA Key information. This needs
                    //to include the private key information.
                    RSA.ImportParameters(RSAKeyInfo);

                    //Decrypt the passed byte array and specify OAEP padding.  
                    //OAEP padding is only available on Microsoft Windows XP or
                    //later.  
                    //decryptedData = RSA.Decrypt(DataToDecrypt, DoOAEPPadding);
                    using (MemoryStream ms = new MemoryStream(DataToDecrypt.Length))
                    {

                        //The buffer that will hold the encrypted chunks

                        byte[] buffer = new byte[_DecryptionBufferSize];

                        int pos = 0;

                        int copyLength = buffer.Length;

                        while (true)
                        {

                            //Copy a chunk of encrypted data / iteration

                            Array.Copy(DataToDecrypt, pos, buffer, 0, copyLength);

                            //Set the next start position

                            pos += copyLength;

                            //Decrypt the data using the private key

                            //We need to store the decrypted data temporarily because we don't know the size of it; 
                            //unlike with encryption where we know the size is 128 bytes. 
                            //The only thing we know is that it's between 1-117 bytes

                            byte[] resp = RSA.Decrypt(buffer, false);

                            ms.Write(resp, 0, resp.Length);

                            //Cleat the buffers

                            Array.Clear(resp, 0, resp.Length);

                            Array.Clear(buffer, 0, copyLength);

                            //Are we ready to exit?

                            if (pos >= DataToDecrypt.Length)

                                break;

                        }

                        //Return the decoded data

                        return ms.ToArray();

                    }
                }
                //return decryptedData;
            }
            //Catch and display a CryptographicException  
            //to the console.
            catch (CryptographicException e)
            {
                Console.WriteLine(e.ToString());

                return null;
            }

        }

        #endregion
    }
}
