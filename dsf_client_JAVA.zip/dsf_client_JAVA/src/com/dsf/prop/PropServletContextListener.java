package com.dsf.prop;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import com.dsf.config.DsfConfig;

public class PropServletContextListener implements ServletContextListener {

    @Override
    public void contextDestroyed(ServletContextEvent arg0) {
        // TODO Auto-generated method stub

    }

    @Override
    public void contextInitialized(ServletContextEvent arg0) {
        try {
            Properties props = new Properties();
            try {
                InputStream in = new BufferedInputStream (arg0.getServletContext().getResourceAsStream("/WEB-INF/classes/info.properties"));
                props.load(in);
                DsfConfig.fkgate = props.getProperty ("fkgate");
                DsfConfig.addr = props.getProperty("addr");
                DsfConfig.payquerynew = props.getProperty("payquerynew");
                DsfConfig.collquerynew = props.getProperty("collquerynew");
                DsfConfig.addrsingle = props.getProperty("addrsingle");
                DsfConfig.skgate = props.getProperty("skgate");
                DsfConfig.skaddr = props.getProperty("skaddr");
                DsfConfig.skaddrsingle = props.getProperty("skaddrsingle");
                DsfConfig.dsfacc = props.getProperty("dsfacc");
                DsfConfig.partner = props.getProperty("partner");
                DsfConfig.key = props.getProperty("key");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }catch(Exception e) {
            System.out.println("加载业务字典失败！");
            e.printStackTrace();
        }
    }
}
