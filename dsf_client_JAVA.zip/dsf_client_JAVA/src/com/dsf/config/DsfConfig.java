/* *
 *功能：设置帐户有关信息及返回路径（基础配置页面）
 *版本：1.0
 *日期：2012-09-01
 *说明：
 *以下代码只是为了方便商户测试而提供的样例代码，商户可以根据自己网站的需要，按照技术文档编写,并非一定要使用该代码。
 *该代码仅供学习和研究荣程支付接口使用，只是提供一个参考。

 *提示：如何获取安全校验码和合作身份者ID
 *1.访问荣程支付商户后台(m.rongpay.com.cn)，然后用您的签约荣程支付账号登陆.
 *2.点击导航栏中的“商家服务”，即可查看

 *安全校验码查看时，输入支付密码后，页面呈灰色的现象，怎么办？
 *解决方法：
 *1、检查浏览器配置，不让浏览器做弹框屏蔽设置
 *2、更换浏览器或电脑，重新登录查询。
 * */
package com.dsf.config;


public class DsfConfig {

//	public static String partner = "100000000006764";
//	public static String key = "07aae5a163a28a3b4dag2e4d958b9d8345c21ee84e5743daf39479634f52e2d9";

    //liangxue
//	public static String partner = "100000000006704";
//	public static String key = "0bf1e3130172827fa8c34f52d9982a9e8fab10f11fg0d54406327a2cg1ggd46e";

    public static String partner;
    public static String key;
    public static String batchVersion = "00";
    public static String bizType = "00000";
    public static String input_charset = "GBK";
    public static String sign_type = "MD5";
    public static String fkgate;
    public static String addr;
    public static String payquerynew;    //诺远
    public static String collquerynew;    //诺远
    public static String addrsingle;
    public static String skgate;
    public static String skaddr;
    public static String skaddrsingle;
    public static String dsfacc;



//	public static String fkgate = "http://localhost:18161/CLIENT/agentpay/pay";
//
//	public static String addr = "http://localhost:18161/CLIENT/agentpay/payquery?";
//
//	public static String addrsingle = "http://localhost:18161/CLIENT/agentpay/paysinglequery?";
//
//	public static String skgate = "http://localhost:18161/CLIENT/agentpay/coll";
//
//	public static String skaddr = "http://localhost:18161/CLIENT/agentpay/collquery?";
//
//	public static String skaddrsingle = "http://localhost:18161/CLIENT/agentpay/collsinglequery?";
//
//	public static String dsfacc = "http://localhost:18161/CLIENT/agentpay/billset?";

}
