package com.dsf.config;

import java.math.BigDecimal;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

public class test {
    InetAddress myIPaddress = null;

    InetAddress myServer = null;

    public static void main(String args[]) {
        String fromIp = "192.168.0.180";
        String ip ="192.168.1.103#192.168.0.180#  ";
        Map<String,String> ipMap = new HashMap<String, String>();
        if (ip.contains("#")) {
            String[] split = ip.split("#");
            for (String ipSplit : split) {
                if (StringUtils.isNotBlank(ipSplit)) {
                    ipMap.put(ipSplit.trim(), ipSplit);
                }
            }
        }else{
            ipMap.put(ip, ip);
        }
        if (!ipMap.containsKey(fromIp.trim())) {
            System.out.println("IP不匹配");
        }else{
            System.out.println("匹配着呢");
        }
    }

    // 取得LOCALHOST的IP地址
    public InetAddress getMyIP() {
        try {
            myIPaddress = InetAddress.getLocalHost();
        } catch (UnknownHostException e) {
        }
        return (myIPaddress);
    }

    // 取得 www.abc.com 的IP地址
    public InetAddress getServerIP() {
        try {
            myServer = InetAddress.getByName("www.reapal.com");
        } catch (UnknownHostException e) {
        }
        return (myServer);
    }
}