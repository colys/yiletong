package com.dsf.config;

import java.security.KeyPair;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.crypto.Cipher;

public class test1 {
    //公钥加密
    public byte[] PublicEncrypt(KeyPair key,String str)throws Exception {
        Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        cipher.init(Cipher.ENCRYPT_MODE, key.getPublic());
        return cipher.doFinal(str.getBytes("UTF8"));
    }

    //公钥解密
    public byte[] PublicDECRYPT (KeyPair key,byte[]  data)throws Exception {
        Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        cipher.init(Cipher.DECRYPT_MODE, key.getPublic());
        return cipher.doFinal(data);
    }

    //私钥加密
    public byte[] PrivateEncrypt (KeyPair key,String str)throws Exception {
        Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        cipher.init(Cipher.ENCRYPT_MODE, key.getPrivate());
        return cipher.doFinal(str.getBytes("UTF8"));
    }

    //私钥解密
    public byte[] PrivateDECRYPT(KeyPair key,byte[]  data)throws Exception  {
        Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        cipher.init(Cipher.DECRYPT_MODE, key.getPrivate());
        return cipher.doFinal(data);
    }


    public static void main(String args[]) throws Exception {
        Calendar calendar = Calendar.getInstance(); //得到日历
        calendar.setTime(new SimpleDateFormat("yyyy-MM-dd").parse("2014-05-28"));//把当前时间赋给日历
        calendar.add(Calendar.DAY_OF_MONTH, -1);  //设置为前一天
        Date dBefore = calendar.getTime();   //得到前一天的时间
        System.out.println(new SimpleDateFormat("yyyy-MM-dd").format(dBefore));
//        String str = "Hello World!";
//        KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
//        keyGen.initialize(1024);
//        KeyPair key = keyGen.generateKeyPair();
//        test1 t = new test1();
//        System.out.println("加密前原文:"+str);
//        byte[] data = t.PublicEncrypt(key,str);
//        System.out.println("私钥解密后:"+new String(t.PrivateDECRYPT(key,data)));
//        byte[] data1 = t.PrivateEncrypt(key,str);
//        System.out.println("公钥解密后:"+new String(t.PublicDECRYPT(key,data1)));
    }
}

