运行此demo必读：

在window系统中运行此项目前提：
   建立如下文件夹：D:/Workbench/runtime/upload/kindeditor/
   
在linux系统中运行此项目：
   建立如下文件夹：/home/appuser/kindeditor/


//文件保存目录路径
//String savePath = SystemConfigUtil.getKindeditorUploadFileRootPath();
String savePath = "D:/Workbench/runtime/upload/kindeditor/";//pageContext.getServletContext().getRealPath("/") + "attached/";
//String savePath = "/home/appuser/kindeditor/";

//文件保存目录URL
String saveUrl  = "D:/Workbench/runtime/upload/kindeditor/";
//String saveUrl  =  "/home/appuser/kindeditor/";